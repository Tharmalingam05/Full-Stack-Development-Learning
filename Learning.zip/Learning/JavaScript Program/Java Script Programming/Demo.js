function samsung()
{
    console.log("This is samsung phone")
}

function iphone()
{
    console.log("This is iphone")
}

function redmi()
{
    console.log("This is redmi phone")
}

function oppo()
{
    console.log("This is oppo phone")
}

samsung()
iphone()
redmi()
oppo()