function add(a,b)
{
    console.log(a+b)
}


function area(length,breath)
{
    var result=length*breath
    console.log(result)
}

// return type
function add(a,b)
{
    return a+b
}

var result=add(2,3)
console.log(result)