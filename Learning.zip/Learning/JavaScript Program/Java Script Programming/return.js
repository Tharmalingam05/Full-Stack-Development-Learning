function myname()
{
    return "Santhosh"
}

var a=myname()
console.log(a)