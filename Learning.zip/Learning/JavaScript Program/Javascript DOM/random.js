var a=Math.random()
console.log(Math.floor(a*10)+1)

// var b=Math.floor(9.6793)
// console.log(b)
