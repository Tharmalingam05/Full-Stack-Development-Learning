// Selecting popup box and overlay button

var overlay=document.querySelector(".overlay")
var popbox=document.querySelector(".popbox")

var addpopbotton=document.getElementById("addpopbotton")

addpopbotton.addEventListener("click",function(){
    overlay.style.display="block"
    popbox.style.display="block"
})

// function click()
// {
//     overlay.style.display="block"
//     popbox.style.display="block"
// }

// Select Cancel Button
var cancelbutton=document.getElementById("cancelbutton")
cancelbutton.addEventListener("click",function(event){
    event.preventDefault()

    overlay.style.display="none"
    popbox.style.display="none"
})

// Select container ,booktitle,bookauthor,bookdescription

var addbook=document.getElementById("addbook")
var container=document.querySelector(".container")
var bookauthor=document.getElementById("bookauthor")
var booktitle=document.getElementById("booktitle")
var bookdescription=document.getElementById("bookdescription")

addbook.addEventListener("click",function(event){
    event.preventDefault()

    var div=document.createElement("div")
    div.setAttribute("class","bookcontainer")
    
    // div.innerHTML= `<h1>${booktitle.value}</h1>`
    div.innerHTML=` <h2>${booktitle.value}</h2>
    <h5>${bookauthor.value}</h5>
    <p>${bookdescription.value}</p>
    <button onclick="deletebook(event)">Delete</button>
    `

    container.append(div)

    overlay.style.display="none"
    popbox.style.display="none"
})

function deletebook(event)
{
    event.target.parentElement.remove()
}
