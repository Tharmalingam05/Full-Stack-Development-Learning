var fruit="apple"

// Creating array

var fruit=["apple","orange","mango","banana"]
console.log(fruit)

console.log(fruit.length)

console.log(fruit[0])
console.log(fruit[1])

for(count=0;count<fruit.length;count=count+1)
{
    // console.log(count)
    console.log(fruit[count])
}