var overlay=document.querySelector(".overlay")
var popbox=document.querySelector(".popbox")

var plus=document.getElementById("plus")
plus.addEventListener("click",function()
{
    overlay.style.display="block"
    popbox.style.display="block"
})

var cancelpop=document.getElementById("cancelpop")
cancelpop.addEventListener("click",function()
{
    overlay.style.display="none"
    overlay.style.display="none"
})

var container=document.querySelector(".container")
var addbook=document.getElementById("addbook")
var author=document.getElementById("author")
var title=document.getElementById("title")
var des=document.getElementById("des")

addbook.addEventListener("click",function(){

    var div=document.createElement("div")
    div.setAttribute("class","bookcontainer")

    div.innerHTML= ` <h2>${title.value}</h2>
    <h4>${author.value}</h4>
    <p>${author.des}</p>

    <button>Delete</button>`

    container.append(div)

    overlay.style.display="none"
    popbox.style.display="none"

})
