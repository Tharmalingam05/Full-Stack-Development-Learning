using System;

class AnoMet
{
    public void Display()
    {
        List<String>name=new List<string>(){"Praveen","Senthil","Naidu"};

        foreach(string st in name)
        {
            Console.WriteLine(st);
        }
    }
}