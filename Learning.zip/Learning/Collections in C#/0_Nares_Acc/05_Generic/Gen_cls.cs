using System;

class Gen_cls
{
    public void Add(int a,int b)
    {
        Console.WriteLine(a+b);
    }

    public void sub(int a,int b)
    {
        Console.WriteLine(a-b);
    }
    public void mul(int a ,int b)
    {
        Console.WriteLine(a*b);
    }
    public void div(int a,int b)
    {
        Console.WriteLine(a/b);
    }
}