﻿using System;
using System.Collections.Generic;

class Program 
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Generic List in C-Sharp---");
        Console.WriteLine();

        List<int>lst=new List<int>();
        lst.Add(10);
        lst.Add(20);
        lst.Add(30);
        lst.Add(40);
        lst.Add(50);

        // Using for loop .Because based on index value.
        for(int i=0;i<lst.Count;i++)
        {
            Console.Write(lst[i] +" ");
        }
        Console.WriteLine();

        // Insert Item 
        lst.Insert(3,35);

        // Using foreach loop
        foreach(int val in lst)
        {
            Console.Write(val+" ");
        }       
        Console.ReadLine();

        // Removing Item

        lst.Remove(20);
        lst.RemoveAt(1);
        
        foreach(int val in lst)
        {
            Console.Write(val+" ");
        }

        Console.ReadLine();
    }
}