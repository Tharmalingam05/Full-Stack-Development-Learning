﻿using System;
using System.Collections.Generic;

        /* Generic Delegates :
            Func
            Action
            Predicate */
class Program
{
    public delegate double delegate1(int x,float y,double z);
    public delegate void delegate2(int x,float y,double z);
    public delegate bool delegate3(string str);
    public static void Main(String[] args)
    {
        Console.WriteLine("---Delegates in C-Sharp");

        // delegate1 obj1=new delegate1(function name);  Another method

        delegate1 obj1=Dele_cls.Addnums1;
        double result=obj1.Invoke(100,3.45f,54.67);  // It's return the value.
        Console.WriteLine(result);

        delegate2 obj2=Dele_cls.Addnums2;
        obj2.Invoke(150,3.45f,78.980);     // It's does not return the value.

        delegate3 obj3=Dele_cls.checkLength;
        bool stat=obj1.Invoke("Santhosh");
        Console.WriteLine(stat);

        Console.ReadLine();
    }
}