using System;
class Dele_cls
{
    public static double Addnums1(int x,float f,double z)  // Value returing method.
    {
        return x+f+z;
    }

    public static void Addnums2(int x,float y,double z)
    {
        Console.WriteLine(x+y+z);
    }
    public static bool checkLength(string str)
    {
        if(str.Length>5)
        return true;

        else return false;
    }
}