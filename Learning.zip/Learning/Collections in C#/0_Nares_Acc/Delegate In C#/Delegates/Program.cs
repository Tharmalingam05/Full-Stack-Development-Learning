﻿using System;
class Program
{
    /* It also belike a function creation and also know as (Abstract Class)*/
    // Delegate Creation
    public delegate int compute(int a,int b);  // Arguments must be same
    public delegate int Calc(int n);
    public static void Main(String[] args)
    {
        Console.WriteLine("---Delegates in C-Sharp---");
        Console.WriteLine();

        compute fun=new compute(Deleg_Func.sum);     // Here,we will use Func name
        Console.WriteLine(fun(12,13));

        fun=new compute(Deleg_Func.mul);
        Console.WriteLine(fun(2,3));

        Console.WriteLine("--------------");

        // Calc cl=new Calc(Sample.Print);
    
        // Console.WriteLine(cl(5));
    }
}