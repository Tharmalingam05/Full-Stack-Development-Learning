﻿using System;
class Program 
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Delegate in Lambda Function---");
        Console.WriteLine();

        Func<int,double,double,double> obj1=(x,y,z) => x+y+z;
        double result=obj1(12,34,45.50);
        Console.WriteLine(result);

        Action<int,double,double> obj2=(x,y,z) =>Console.WriteLine(x+y+z);
        obj2(12,12,12);

        Predicate<string> obj3=(str) =>
        {
            if(str.Length>5)
            return true;

            else return false;
        };
        bool res=obj3("Hello");
        Console.WriteLine(res);

        Console.ReadLine();

    }
}