﻿using System;

class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Generic In C-Sharp---");
        Console.WriteLine();

        Genric obj=new Genric();
        bool result=obj.Compare1(5.5f,5.5f);
        Console.WriteLine(result);

        Genric obj1=new Genric();
        bool res=obj1.Compare2<int>(2,2);   // Here ,we will give a type and (type safe)
        Console.WriteLine(res);

        Genric obj2=new Genric();
        bool res1=obj2.Compare2<float>(2.5f,2.5f);
        Console.WriteLine(res1);
        
    }
}