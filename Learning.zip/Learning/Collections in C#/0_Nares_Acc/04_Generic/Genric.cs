using System;

class Genric 
{
    public bool Compare(int a ,int b) // Here,only give a integer value only
    {
        if(a==b)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
     public bool Compare1(object a ,object b)  // Now we will give any type of data
    {
        if(a.Equals(b))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public bool Compare2<T>(T a,T b)
    {
        if(a.Equals(b))
         return true;
        
        else return false;
    }
}