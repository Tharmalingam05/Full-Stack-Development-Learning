﻿using System.IO;
using System;

class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Dictionary in Generic---");
        Console.WriteLine();

        Dictionary<string,object> dt=new Dictionary<string, object>();

        dt.Add("id",7208);
        dt.Add("name ","Santhosh");
        dt.Add("Salary ",72000);
        dt.Add("Location ","Coimbatore");
        dt.Add("Department ","Computer Science");

        foreach(string str in dt.Keys)
        {
            Console.WriteLine(str +" "+ dt[str]);
        }

        // In case of a generic collections the type of values we want to store under 
        // the collections need not be pre-defined typed only like int ,float,char,string,
        // bool etc..., But it can alse be some user-defined type also.

        List<Customer> customers =new List<Customer>();

        Customer c1=new Customer{custid=101,name="Santhosh",city="CBE",balance=12000};
        Customer c2=new Customer{custid=105,name="Praveen",city="Trichy",balance=45000};
        Customer c3=new Customer{custid=103,name="Senthil",city="Trichy",balance=49000};
        Customer c4=new Customer{custid=102,name="Naidu",city="Trichy",balance=67000};

        customers.Add(c1);
        customers.Add(c2);
        customers.Add(c3);
        customers.Add(c4);

        customers.Sort();

        foreach(Customer obj in customers)
        {
            Console.WriteLine(obj.custid+" "+obj.name+" "+obj.city+" "+obj.balance);
        }
        Console.ReadLine();

        Console.WriteLine("-----------------------------------------------");

        Student st1=new Student{sid=111,name="Aravinth",cls=12,marks=90};
        Student st2=new Student{sid=333,name="Dinesh",cls=10,marks=80};
        Student st3=new Student{sid=555,name="Santhosh",cls=09,marks=97};
        Student st4=new Student{sid=444,name="Praveen",cls=11,marks=89};
        Student st5=new Student{sid=222,name="Senthil",cls=12,marks=99};

        List<Student> st=new List<Student>(){st1,st2,st3,st4,st5};

        // For sorting a list
        st.Sort();
        //st.Reverse();

        // Compare based on {Marks}
        CompareStudent cs=new CompareStudent();
        st.Sort(cs);

        foreach(Student ss in st)
        {
            Console.WriteLine(ss.sid+" "+ss.name+" "+ss.cls+" "+ss.marks);
        }
        Console.ReadLine();
    }
}