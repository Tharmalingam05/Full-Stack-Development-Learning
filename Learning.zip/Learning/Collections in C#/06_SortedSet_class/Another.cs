using System;
using System.Collections.Generic;

class Another
{
    public void Display()
    {
        SortedSet<String>name=new SortedSet<string>(){"James","Alto","Manik","Boi","James"};

        foreach(var st in name)
        {
            Console.WriteLine(st);
        }
    }
}