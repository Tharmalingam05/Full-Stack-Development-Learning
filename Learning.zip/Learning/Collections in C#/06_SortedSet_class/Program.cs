﻿using System;
using System.Collections.Generic;

class Program 
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---SortedSet Class In C-Sharp---");
        Console.WriteLine();

        SortedSet<string> names=new SortedSet<string>();
        names.Add("Santhosh");
        names.Add("Raja");
        names.Add("Arjun");
        names.Add("Manikkam");
        names.Add("Naidu");
        names.Add("Santhosh");

        // Doesn't allow duplicate elements

        foreach(string str in names)
        {
            Console.WriteLine(str);
        }

        Console.WriteLine("---Another Method In SortedSet---");

        Another an=new Another();
        an.Display();
    }
}